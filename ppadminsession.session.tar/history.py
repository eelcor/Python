Session = sessionmaker(bind=engine)
# *** Spyder Python Console History Log ***
session.add(marije)
session.commit()
generate_password_hash('Hallo')
session.query(Gebruiker).all()
test = session.query(Gebruiker).all()
marije.check_password('Leiden79')
marije.check_password('Leiden7')
Gebruiker()
test.check_password('Leiden79
test.check_password('Leiden79')
test = Gebruiker.query.all().first()
test = session.query().all().first()
test = session.query().all()
test = session.query(Gebruiker).all().first
test = session.query(Gebruiker).all().first()
test = session.query(Gebruiker).first()
test
test.check_password('Leiden79')
test.check_password('Leiden70')
runfile('D:/Development/Python/PPAdmin/app/model.py', wdir=r'D:/Development/Python/PPAdmin/app')
session.close()
runfile('D:/Development/Python/PPAdmin/app/model.py', wdir=r'D:/Development/Python/PPAdmin/app')
import model
marije = model.Persoon("Marije Assink", "Leiden79")
marije = model.Gebruiker("Marije Assink", "Leiden79")
from sqlalchemy.orm import sessionmaker
Session = sessionmaker(bind=engine)
session = Session()
session.add(marije)
session.commit()
session.query(Gebruiker).first()
gebruiker = session.query(Gebruiker).first()
gebruiker.check_password('Leiden79')
marije = model.Gebruiker("marije.assink", "Leiden79")
session.add(marije)
session.commit()
gebruiker = session.query(Gebruiker).first()
gebruiker.check_password('Leiden79')
runfile('D:/Development/Python/PPAdmin/app/__init__.py', wdir=r'D:/Development/Python/PPAdmin/app')
session.close()
exit
exit()
runfile('D:/Development/Python/PPAdmin/app/model.py', wdir=r'D:/Development/Python/PPAdmin/app')
import model
from sqlalchemy.orm import sessionmaker
runfile('D:/Development/Python/PPAdmin/app/model.py', wdir=r'D:/Development/Python/PPAdmin/app')
import model
from sqlalchemy.orm import sessionmaker
Session = sessionmaker
session = Session()
Session = sessionmaker(bind=engine)
session = Session()
marije = model.Gebruiker('marije.assink','Leiden79')
session.add(marije)
session.commit()
test = session.query(Gebruiker).first()
test
test.check_password('Leiden79')
test.check_password('Leiden80')
test.set_password('eelco.rouw')
session.add(test)
session.commit()
test = session.query(Gebruiker).first()
test.check_password('Leiden80')
test.check_password('Leiden79')
test.check_password('eelco.rouw')
test.set_password('Leiden79')
session.add(test)
session.commit()
eelco = Gebruiker('eelco.rouw','cacivaysda')
session.add(eelco)
session.commit()
test = session.query(Gebruiker).filter_by(user=='marije.assink')
test = session.query(Gebruiker).filter_by(Gebruiker.user == 'marije.assink')
test = session.query(Gebruiker).filter_by(Gebruiker.user = 'marije.assink')
test = session.query(Gebruiker).filter(Gebruiker.user = 'marije.assink')
test = session.query(Gebruiker).filter(Gebruiker.user == 'marije.assink')
test = session.query(Gebruiker).filter(Gebruiker.user == 'marije.assink').all()
test
test(0)
test[0]
test.tail()
test[0].user
exit
a = []
if a == []
a == []
empty(a)
 a = [1]
a = [1,2]
a[0]
a[1]
a
a = [1]
a[0]
a = []
a[0]
exit